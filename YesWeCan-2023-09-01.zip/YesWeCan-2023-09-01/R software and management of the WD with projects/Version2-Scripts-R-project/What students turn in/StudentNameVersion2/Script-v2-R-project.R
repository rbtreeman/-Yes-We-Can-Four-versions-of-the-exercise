# BEFORE EXECUTING THIS SCRIPT, BE SURE THAT:
#   
# 1) THERE IS A FOLDER ON YOUR COMPUTER 
# NAMED "<YourName>Version2".
# 
# 2)AN RSTUDIO PROJECT FILE WITH THE NAME  
# "<YourName>Version2.Rproj" IS STORED IN THE
# "<YourName>Version2" FOLDER.
# 
# AND
# 
# 3) A COPY OF ACS2018Extract.csv IS SAVED IN 
# "<YourName>Version2".

# EVERY TIME YOU WORK ON OR EXECUTE THIS SCRIPT, YOU
# SHOULD EITHER
# --LAUNCH THE RSTUDIO SESSION BY DOUBLE-CLICKING ON THE
# PROJECT FILE (<YourName>Version2.Rproj).
# OR
# --WITH RSTUDIO ALREADY LAUNCHED, USE RSTUDIO'S MENU
# TO CHOOSE File->Open Project…, THEN BROWSE TO AND
# SELECT THE PROJECT FILE (<YourName>Version2.Rproj) IN YOUR PROJECT FOLDER.

# EITHER ONE OF THESE METHODS WILL ENSURE THAT THE
# "<YourName>Version2" FOLDER IS DESIGNATED AS R's 
# WORKING DIRECTORY.

# This script:
# -reads the 2018 ACS data extract into a data frame
# -creates a table of group means of income by race and sex
# -generates a bar graph showing group means of income by
#  race and sex


# Clear the environment
rm(list = ls())

# Load packages
library("tidyverse")

# Read the data in ACS2018Extract.csv into a data frame
ACS2018Extract<-read_csv("ACS2018Extract.csv")

# Construct the table of mean income by race and sex
table<-ACS2018Extract |>
  summarize(
    frequency=n(),
    mean_income=mean(income),
    .by=c(race, sex)
    ) |>
  arrange(race, sex)

# Display the table of mean income by race and sex
table

  
# Construct the bar graph of mean income by race and sex
graph<-ggplot(table, aes(race, mean_income))+geom_col(aes(fill = sex), position="dodge")

# Display the bar graph of mean income by race and sex
graph


