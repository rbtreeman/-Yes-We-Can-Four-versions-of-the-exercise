# BEFORE EXECUTING THIS SCRIPT, BE SURE THAT:
#   
# 1) THERE IS A FOLDER ON YOUR COMPUTER NAMED "<YourName>Version3".
# 
# 2)"<YourName>Version3" IS DESIGNATED AS R'S WORKING DIRECTORY. IF NECESSARY, MANUALLY SET THE WORKING DIRECTORY TO "<YourName>Version3".
# 
# AND
# 
# 3) A COPY OF ACS2018Extract.csv IS SAVED IN "<YourName>Version3".

# This script:
# -reads the 2018 ACS data extract into a data frame
# -creates a table of group means of income by race and sex
# -saves the table in a .csv file, which is saved in the Output folder 
# -generates a bar graph showing group means of income by race and sex
# -saves the bar graph in a .csv file, which is saved in the Output folder 

# Clear the environment
rm(list = ls())

# Load packages
library("tidyverse")
library("writexl")

# Read the data in ACS2018Extract.csv into a data frame
ACS2018Extract<-read_csv("ACS2018Extract.csv")

# Construct the table of mean income by race and sex
table<-ACS2018Extract |>
  summarize(
    frequency=n(),
    mean_income=mean(income),
    .by=c(race, sex)
  ) |>
  arrange(race, sex)

# Display the table of mean income by race and sex
table

# Save the table in a .csv file
write.csv(table, "MeanIncomes.csv")

# Construct the bar graph of mean income by race and sex
graph<-ggplot(table, aes(race, mean_income))+geom_col(aes(fill = sex), position="dodge")

# Save the bar graph in a .png file
ggsave("MeanIncomes.png")

# Display the bar graph of mean income by race and sex
graph
# 
# 
# library(tidyverse) # for data wrangling
# library(writexl)
# 
# 
# df<-read_csv("ACS2018Extract.csv")
# 
# 
# version3_table<-df |>
#   summarize(
#     frequency=n(),
#     mean_income=mean(income),
#     .by=c(race, sex)
#   ) |>
#   arrange(race, sex)
# 
# version3_table
# 
# write.csv(version3_table, "version3_table.csv")
# 
# 
# 
# 
#   
# version3_graph<-ggplot(version3_table, aes(race, mean_income))+geom_col(aes(fill = sex), position="dodge") 
# 
# 
# version3_graph
# 
# ggsave("version3_graph.png")